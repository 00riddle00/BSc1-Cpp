#include <iostream> // Stream declarations

using namespace std;

int main() {

cout << "Hello, World! Today is "

<< 7 << " of September!" << endl;

}
