#include <iostream>

using namespace std;

int main() {

// Specifying formats with manipulators:

cout << "a number in decimal: "

<< dec << 15 << endl;

cout << "in octal: " << oct << 15 << endl;

cout << "in hex: " << hex << 15 << endl;

cout << "a floating-point number: "

<< 3.14159 << endl;

cout << "symbol A denoted through its ASCII code: "

<< char(65) << endl;

}
